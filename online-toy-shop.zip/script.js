function buynow() {
    alert("You're going to buy this item.");
}
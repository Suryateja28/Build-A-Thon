<?php
$products = [
    [
        'name' => 'Shivaaro Doll Fashion',
        'image' => 'https://m.media-amazon.com/images/I/51Q4OCo0rnL._SX450_.jpg',
        'details' => 'BARBIE SET IS VERY ENJOYFUL FOR GIRL. Easy to use. It helps improving motor skills.',
        'price' => 1299
    ],
    [
        'name' => 'GRAPHENE Monster Truck',
        'image' => 'https://m.media-amazon.com/images/I/71cKF9eGZGL._AC_UL480_FMwebp_QL65_.jpg',
        'details' => 'High-density alloy, shock-proof, 360° rotating. Fun for boys.',
        'price' => 999
    ]
];
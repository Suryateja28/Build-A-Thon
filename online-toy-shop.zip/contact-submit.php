<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST['name'] . "," . $_POST['phone'] . "," . $_POST['email'] . "," . $_POST['message'] . "\n";
    file_put_contents("contact-submissions.csv", $data, FILE_APPEND);
    echo "<script>alert('Thank you! We will contact you soon.'); window.history.back();</script>";
}
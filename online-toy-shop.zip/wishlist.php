<?php
session_start();
if (!isset($_SESSION['wishlist'])) {
    $_SESSION['wishlist'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = $_POST['product'];
    $_SESSION['wishlist'][] = $product;
    echo "<script>alert('Added to wishlist!'); window.history.back();</script>";
}
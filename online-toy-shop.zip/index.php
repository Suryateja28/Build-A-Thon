<?php include 'products.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ONLINE SHOPPING</title>
    <script src="script.js" defer></script>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-black">

    <header class="bg-yellow-300 p-4 text-center">
        <h1 class="text-2xl font-bold">TOYS & Games ONLINE SHOPPING <br> BY HACK VERTOS</h1>
        <button onclick="alert('You have to go back to signup page')" class="mt-2 bg-blue-600 text-white px-4 py-1 rounded">Login</button>
    </header>

    <nav class="bg-white shadow p-2">
        <ul class="flex justify-around">
            <li><a href="#home" class="hover:text-blue-500">Home</a></li>
            <li><a href="#kids" class="hover:text-blue-500">Kids</a></li>
            <li><a href="#category" class="hover:text-blue-500">Category</a></li>
            <li><a href="#adults" class="hover:text-blue-500">Adults</a></li>
            <li><a href="#games" class="hover:text-blue-500">Games</a></li>
            <li><a href="#wishlist" class="text-red-500">&hearts;</a></li>
            <li><a href="#Contact" class="hover:text-blue-500">Contact</a></li>
        </ul>
    </nav>

    <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
        <?php foreach ($products as $product): ?>
            <div class="bg-white rounded shadow p-4">
                <img src="<?= $product['image'] ?>" alt="product" class="w-full h-48 object-cover">
                <h2 class="text-xl font-semibold mt-2"><?= $product['name'] ?></h2>
                <p class="text-sm my-2"><?= $product['details'] ?></p>
                <p class="text-lg font-bold text-green-600">&#8377; <?= $product['price'] ?></p>
                <form action="wishlist.php" method="POST" class="space-x-2 mt-2">
                    <input type="hidden" name="product" value="<?= $product['name'] ?>">
                    <button type="submit" class="bg-green-500 text-white px-3 py-1 rounded">Add to Wishlist</button>
                    <button type="button" onclick="buynow()" class="bg-blue-500 text-white px-3 py-1 rounded">Buy Now</button>
                </form>
            </div>
        <?php endforeach; ?>
    </section>

    <section id="Contact" class="bg-gray-200 p-4">
        <h2 class="text-center text-2xl font-bold mb-4">Contact Us</h2>
        <form action="contact-submit.php" method="POST" class="space-y-4 max-w-md mx-auto">
            <input class="w-full p-2 border border-gray-300 rounded" type="text" name="name" placeholder="Enter Your name">
            <input class="w-full p-2 border border-gray-300 rounded" type="text" name="phone" placeholder="Enter Your Phone">
            <input class="w-full p-2 border border-gray-300 rounded" type="email" name="email" placeholder="Enter Your Email">
            <textarea class="w-full p-2 border border-gray-300 rounded" name="message" rows="4" placeholder="Elaborate your concern"></textarea>
            <button class="bg-black text-white px-4 py-2 rounded" type="submit">Submit</button>
        </form>
    </section>

    <footer class="text-center py-4 bg-black text-white">
        &copy; 2025 All rights reserved.
    </footer>

</body>
</html>